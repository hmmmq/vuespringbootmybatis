package com.example.demo.service;

import com.example.demo.entity.Comments;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lintianqi
 * @since 2024-09-07
 */
public interface ICommentsService extends IService<Comments> {

}
