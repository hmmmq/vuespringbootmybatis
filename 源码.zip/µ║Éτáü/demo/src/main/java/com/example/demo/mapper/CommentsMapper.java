package com.example.demo.mapper;

import com.example.demo.entity.Comments;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lintianqi
 * @since 2024-09-07
 */
public interface CommentsMapper extends BaseMapper<Comments> {

}
