<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
  <style scoped>
  /* 引入的样式文件 */
  @import '@/assets/css/bootstrap.min.css';
  @import '@/assets/css/style.css';
  </style>
  